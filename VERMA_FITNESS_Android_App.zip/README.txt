VERMA FITNESS — Android installable web app (PWA)

Included:
- index.html: workout app
- manifest.webmanifest: install metadata
- sw.js: offline cache
- icon.svg: app icon

IMPORTANT:
This is a Progressive Web App, not a compiled APK. For Android installation:
1. Upload the contents of this folder to a secure HTTPS host (for example, a static website host).
2. Open the hosted site in Chrome on your Android phone.
3. Use Chrome menu > Install app (or Add to Home screen).
4. The app can then open in its own app-like window. Progress is saved on that device/browser.

An APK is not compiled in this environment. The app's progress is stored locally in browser storage.
